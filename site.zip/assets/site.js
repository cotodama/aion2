(function(){
 'use strict';
 const root=document.body.dataset.root||'';
 const skinControl=document.getElementById('skin-selector');
 const skinNames=['classic','compact','reading'];
 let activeSkin='classic';
 try{activeSkin=localStorage.getItem('atreia-skin')||activeSkin;}catch{}
 const requestedSkin=new URLSearchParams(location.search).get('skin');
 if(skinNames.includes(requestedSkin))activeSkin=requestedSkin;
 if(!skinNames.includes(activeSkin))activeSkin='classic';
 function applySkin(skin){activeSkin=skin;document.documentElement.dataset.skin=skin;if(skinControl)skinControl.value=skin;try{localStorage.setItem('atreia-skin',skin);}catch{}}
 applySkin(activeSkin);
 if(skinControl)skinControl.addEventListener('change',()=>{applySkin(skinControl.value);try{const u=new URL(location.href);u.searchParams.set('skin',activeSkin);history.replaceState(null,'',u.href);}catch{}});
 document.addEventListener('click',event=>{const a=event.target.closest('a');if(!a)return;const raw=a.getAttribute('href');if(!raw||raw.startsWith('#')||/^[a-z]+:/i.test(raw)||raw.startsWith('//'))return;const u=new URL(a.href);if(!u.pathname.endsWith('.html'))return;if(!u.searchParams.has('skin'))u.searchParams.set('skin',activeSkin);a.href=u.href;});
 const norm=s=>String(s).normalize('NFKC').toLowerCase().replace(/[ァ-ヶ]/g,c=>String.fromCharCode(c.charCodeAt(0)-0x60)).replace(/[\s・･ー_\-]+/g,'');
 const freshness=document.getElementById('freshness');
 if(freshness&&window.ATREIA_DATE){const days=Math.floor((Date.now()-new Date(window.ATREIA_DATE).getTime())/86400000);if(days>=3)freshness.textContent='保存資料：確認から'+days+'日経過';}
 const results=document.getElementById('search-results');
 if(results){
  const input=document.getElementById('q'),form=input.closest('form'),type=document.getElementById('type-filter'),category=document.getElementById('category-filter'),count=document.getElementById('search-count'),more=document.getElementById('more-results');
  const params=new URLSearchParams(location.search);input.value=params.get('q')||'';type.value=params.get('type')||'';category.value=params.get('category')||'';
  const labels={guide:'ガイド',term:'用語',qa:'Q&A',path:'段階別',history:'年代記',news:'ニュース',column:'創作コラム'};
  const corpus=(window.ATREIA_SEARCH||[]).map(e=>({...e,nt:norm(e.title),na:norm(e.aliases.join(' ')),ns:norm(e.summary),nb:norm(e.text)}));
  let found=[],shown=0;
  function append(){const part=found.slice(shown,shown+30);const fragment=document.createDocumentFragment();for(const e of part){const li=document.createElement('li'),meta=document.createElement('div'),h=document.createElement('h2'),a=document.createElement('a'),p=document.createElement('p');meta.className='result-meta';meta.textContent=(labels[e.kind]||e.kind)+' ／ '+e.category;a.href=root+e.url;a.textContent=e.title;h.append(a);p.textContent=e.summary;li.append(meta,h,p);fragment.append(li);}results.append(fragment);shown+=part.length;more.hidden=shown>=found.length;}
  function render(updateURL=true){const query=input.value.trim(),tokens=query.split(/[\s　]+/).filter(Boolean).map(norm);found=corpus.filter(e=>(!type.value||e.kind===type.value)&&(!category.value||e.category===category.value)).map(e=>{let score=0;for(const token of tokens){const matched=e.nt.includes(token)||e.na.includes(token)||e.ns.includes(token)||e.nb.includes(token);if(!matched)return null;score+=e.nt===token?120:e.nt.includes(token)?60:e.na.includes(token)?45:e.ns.includes(token)?18:5;}return {...e,score};}).filter(Boolean).sort((a,b)=>b.score-a.score||a.title.localeCompare(b.title,'ja'));results.replaceChildren();shown=0;count.textContent=(query?'「'+query+'」：':'全項目：')+found.length+'件'+(!corpus.length?'（検索データを読み込めませんでした）':'');if(!found.length){const p=document.createElement('p');p.textContent='該当する項目はありません。短い用語や略語で試すか、総目次・Q&A目次から探してください。';results.append(p);}append();if(updateURL){const q=new URLSearchParams();if(query)q.set('q',query);if(type.value)q.set('type',type.value);if(category.value)q.set('category',category.value);try{history.replaceState(null,'',location.pathname+(q.size?'?'+q.toString():''));}catch{}}}
  form.addEventListener('submit',event=>{event.preventDefault();render();});let timer;input.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>render(),140);});type.addEventListener('change',()=>render());category.addEventListener('change',()=>render());more.addEventListener('click',append);render(false);
 }
 const bf=document.getElementById('battle-filter');if(bf){const rows=[...document.querySelectorAll('#battle-table tbody tr[data-status]')];function apply(){const data=new FormData(bf);let n=0;for(const row of rows){const yes=(!data.get('region')||norm(row.dataset.region).includes(norm(data.get('region'))))&&(!data.get('server')||norm(row.dataset.server).includes(norm(data.get('server'))))&&(!data.get('status')||row.dataset.status===data.get('status'));row.hidden=!yes;if(yes)n++;}document.getElementById('battle-count').textContent=n+'件を表示';}bf.addEventListener('input',apply);bf.addEventListener('submit',e=>e.preventDefault());apply();}
})();
